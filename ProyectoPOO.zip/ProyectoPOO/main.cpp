#include "Refugio.h"
#include "Coleccion.h"
#include "Excepciones.h"
#include <cctype>
#include <iostream>
#include <limits>
#include <string>

using namespace std;

class FinDeEntrada {};

template <typename T>
void mostrarCantidad(const Coleccion<T> &coleccion, const string &tipo) {
	cout << "Coleccion de " << tipo << ": " << cantidadDe(coleccion)
		 << " elemento(s).\n";
}

void demostrarColecciones() {
	Coleccion<int> edades;
	Coleccion<string> nombres;
	edades.agregar(3);
	edades.agregar(5);
	nombres.agregar("Max");
	nombres.agregar("Luna");
	mostrarCantidad(edades, "enteros");
	mostrarCantidad(nombres, "textos");
	cout << "Instancias de Coleccion<int>: "
		 << Coleccion<int>::cantidadInstancias() << "\n";
	cout << "Instancias de Coleccion<string>: "
		 << Coleccion<string>::cantidadInstancias() << "\n";
}

void limpiarEntrada() {
	if (cin.fail()) {
		cin.clear();
	}
	cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

int leerEntero(const string &mensaje) {
	int valor;
	while (true) {
		cout << mensaje;
		if (cin >> valor) {
			limpiarEntrada();
			return valor;
		}
		if (cin.eof()) {
			throw FinDeEntrada();
		}
		cout << "Entrada invalida. Debe ingresar un numero.\n";
		limpiarEntrada();
	}
}

string leerTexto(const string &mensaje) {
	string valor;
	while (true) {
		cout << mensaje;
		if (getline(cin, valor) && !valor.empty()) {
			return valor;
		}
		if (cin.eof()) {
			throw FinDeEntrada();
		}
		cout << "Entrada invalida. Debe ingresar texto.\n";
		limpiarEntrada();
	}
}

bool contieneSoloLetrasYEspacios(const string &valor) {
	static const string letrasAcentuadas[] = {
		"á", "é", "í", "ó", "ú", "ü", "ñ",
		"Á", "É", "Í", "Ó", "Ú", "Ü", "Ñ"};
	bool contieneLetra = false;

	for (size_t posicion = 0; posicion < valor.size();) {
		unsigned char caracter = valor[posicion];
		if (isalpha(caracter)) {
			contieneLetra = true;
			++posicion;
			continue;
		}
		if (caracter == ' ') {
			++posicion;
			continue;
		}

		bool esLetraAcentuada = false;
		for (const string &letra : letrasAcentuadas) {
			if (valor.compare(posicion, letra.size(), letra) == 0) {
				posicion += letra.size();
				contieneLetra = true;
				esLetraAcentuada = true;
				break;
			}
		}
		if (!esLetraAcentuada) {
			return false;
		}
	}

	return contieneLetra;
}

template <typename Validador>
string leerTextoValidado(const string &mensaje, Validador esValido,
						 const string &mensajeError) {
	string valor;
	while (true) {
		cout << mensaje;
		if (!getline(cin, valor)) {
			if (cin.eof()) {
				throw FinDeEntrada();
			}
			cout << mensajeError << "\n";
			limpiarEntrada();
			continue;
		}

		if (esValido(valor)) {
			return valor;
		}
		cout << mensajeError << "\n";
	}
}

string leerTextoSoloLetras(const string &mensaje) {
	return leerTextoValidado(
		mensaje, contieneSoloLetrasYEspacios,
		"Entrada invalida. Debe ingresar solo letras y espacios.");
}

bool contieneSoloDigitos(const string &valor) {
	if (valor.empty()) {
		return false;
	}
	for (unsigned char caracter : valor) {
		if (caracter < '0' || caracter > '9') {
			return false;
		}
	}
	return true;
}

string leerTelefono(const string &mensaje) {
	return leerTextoValidado(
		mensaje, contieneSoloDigitos,
		"Entrada invalida. El telefono debe contener solo numeros.");
}

bool esCorreoValido(const string &valor) {
	size_t posicionArroba = valor.find('@');
	if (posicionArroba == string::npos || posicionArroba == 0 ||
		posicionArroba == valor.size() - 1 ||
		valor.find('@', posicionArroba + 1) != string::npos) {
		return false;
	}

	size_t posicionPunto = valor.find('.', posicionArroba + 1);
	if (posicionPunto == string::npos || posicionPunto == valor.size() - 1) {
		return false;
	}

	for (unsigned char caracter : valor) {
		if (!isalnum(caracter) && caracter != '@' && caracter != '.' &&
			caracter != '_' && caracter != '-') {
			return false;
		}
	}
	return true;
}

string leerCorreo(const string &mensaje) {
	return leerTextoValidado(
		mensaje, esCorreoValido,
		"Entrada invalida. Use letras, numeros y solo estos simbolos: @ . _ -.");
}

bool leerSiNo(const string &mensaje) {
	char respuesta;
	while (true) {
		cout << mensaje << " (s/n): ";
		cin >> ws;
		if (cin >> respuesta) {
			if (respuesta == 's' || respuesta == 'S') {
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
				return true;
			}
			if (respuesta == 'n' || respuesta == 'N') {
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
				return false;
			}
		}
		if (cin.eof()) {
			throw FinDeEntrada();
		}
		cout << "Respuesta invalida. Use s o n.\n";
		limpiarEntrada();
	}
}

void mostrarMenu() {
	cout << "\n===== MENU DEL REFUGIO =====\n"
		 << "1. Registrar perro\n"
		 << "2. Registrar gato\n"
		 << "3. Listar animales y filtrar disponibles\n"
		 << "4. Registrar adoptante\n"
		 << "5. Buscar animal por ID\n"
		 << "6. Crear, confirmar o cancelar solicitud de adopcion\n"
		 << "7. Devolver un animal al estado disponible\n"
		 << "8. Mostrar solicitudes e historial de adopciones\n"
		 << "0. Salir\n";
}

void registrarPerro(Refugio &refugio) {
	string nombre = leerTexto("Nombre: ");
	int edad = leerEntero("Edad: ");
	string salud = leerTextoSoloLetras("Estado de salud: ");
	string raza = leerTextoSoloLetras("Raza: ");
	string tamano = leerTextoSoloLetras("Tamano: ");
	refugio.registrarPerro(nombre, edad, salud, raza, tamano);
}

void registrarGato(Refugio &refugio) {
	string nombre = leerTexto("Nombre: ");
	int edad = leerEntero("Edad: ");
	string salud = leerTextoSoloLetras("Estado de salud: ");
	string colorPelaje = leerTexto("Color del pelaje: ");
	bool esDeInterior = leerSiNo("¿Es de interior? (s = adentro, n = afuera)");
	refugio.registrarGato(nombre, edad, salud, colorPelaje, esDeInterior);
}

void buscarAnimal(const Refugio &refugio) {
	int id = leerEntero("ID del animal: ");
	const Animal *animal = refugio(id);
	if (animal == nullptr) {
		cout << "No se encontro un animal con ese ID.\n";
		return;
	}
	animal->mostrarInfo();
}

void registrarAdoptante(Refugio &refugio) {
	string nombre = leerTextoSoloLetras("Nombre: ");
	string telefono = leerTelefono("Telefono: ");
	string correo = leerCorreo("Correo: ");
	string tipoVivienda =
		leerTextoSoloLetras("Tipo de vivienda (casa, departamento, etc.): ");
	refugio.registrarAdoptante(nombre, telefono, correo, tipoVivienda);
}

void gestionarSolicitud(Refugio &refugio) {
	cout << "1. Crear solicitud\n"
		 << "2. Confirmar solicitud\n"
		 << "3. Cancelar solicitud\n";
	int accion = leerEntero("Seleccione una accion: ");

	if (accion == 1) {
		int idAdoptante = leerEntero("ID del adoptante: ");
		int idAnimal = leerEntero("ID del animal: ");
		int idSolicitud = refugio.crearSolicitud(idAdoptante, idAnimal);
		if (idSolicitud == 0) {
			cout << "No se pudo crear la solicitud. Verifique los IDs y la disponibilidad.\n";
		} else {
			cout << "Solicitud creada con ID: " << idSolicitud << "\n";
		}
		return;
	}

	int idSolicitud = leerEntero("ID de la solicitud: ");
	bool resultado = false;
	if (accion == 2) {
		resultado = refugio.confirmarSolicitud(idSolicitud);
	} else if (accion == 3) {
		resultado = refugio.cancelarSolicitud(idSolicitud);
	} else {
		cout << "Accion invalida.\n";
		return;
	}

	cout << (resultado ? "Operacion realizada correctamente.\n"
	                   : "No se pudo realizar la operacion.\n");
}

void devolverAnimal(Refugio &refugio) {
	int idAnimal = leerEntero("ID del animal a devolver: ");
	if (refugio.devolverAnimal(idAnimal)) {
		cout << "El animal ahora esta disponible nuevamente.\n";
	} else {
		cout << "No se pudo devolver el animal. Verifique el ID y su estado.\n";
	}
}

int main() {
	Refugio refugio;
	int opcion;

	do {
		mostrarMenu();
		try {
			opcion = leerEntero("Seleccione una opcion: ");
		} catch (const FinDeEntrada &) {
			cout << "\nFin de la entrada. Saliendo del sistema...\n";
			break;
		}
		cout << '\n';

		try {
		switch (opcion) {
		case 1:
			registrarPerro(refugio);
			break;
		case 2:
			registrarGato(refugio);
			break;
		case 3: {
			bool soloDisponibles = leerSiNo("Desea filtrar solo animales disponibles");
			if (soloDisponibles) {
				refugio.listarAnimalesDisponibles();
			} else {
				refugio.listarAnimales();
			}
			break;
		}
		case 4:
			registrarAdoptante(refugio);
			break;
		case 5:
			buscarAnimal(refugio);
			break;
		case 6:
			gestionarSolicitud(refugio);
			break;
		case 7:
			devolverAnimal(refugio);
			break;
		case 8:
			refugio.listarAdoptantes();
			refugio.listarSolicitudes();
			break;
		case 0:
			cout << "Saliendo del sistema...\n";
			break;
		default:
			cout << "Opcion invalida.\n";
		}
		} catch (const FinDeEntrada &) {
			cout << "\nFin de la entrada. Saliendo del sistema...\n";
			break;
		} catch (const IdDuplicadoException &ex) {
			cout << "Error de ID: " << ex.what() << "\n";
		} catch (const AnimalNoDisponibleException &ex) {
			cout << "Error de disponibilidad: " << ex.what() << "\n";
		} catch (const IndiceInvalidoException &ex) {
			cout << "Error de indice: " << ex.what() << "\n";
		} catch (const out_of_range &ex) {
			cout << "Error de rango: " << ex.what() << "\n";
		} catch (const exception &ex) {
			cout << "Error: " << ex.what() << "\n";
		}
	} while (opcion != 0);

	return 0;
}
